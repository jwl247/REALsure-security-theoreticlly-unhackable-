# 🚀 MODULES 8 & 9 - ONE-COMMAND INSTALL

## ⚡ ULTRA QUICK START

**ONE script installs BOTH modules!**

```bash
sudo ./install_modules_8_9.sh
```

**That's it!** Everything else is automatic. ✅

---

## 📦 WHAT IT INSTALLS

### Module 8: Budget Keeper AI
- ✅ 8 database tables
- ✅ 5 permission levels (Manual → Total Accountability)
- ✅ Real-time purchase checking
- ✅ Partner notifications
- ✅ Bill reminders
- ✅ AI categorization & insights

### Module 9: Secure Settings Lock
- ✅ 9 database tables
- ✅ GPS + Elevation verification
- ✅ Bluetooth partner detection
- ✅ WiFi BSSID verification
- ✅ Behavioral analysis
- ✅ Threat detection
- ✅ Complete audit trail

**Total: 17 new tables + 2 PHP modules = Financial Fort Knox!** 🔐

---

## 🚀 INSTALLATION (3 Steps)

### Step 1: Upload Installer
```bash
# Copy to USB, then on server:
cp /media/usb/install_modules_8_9.sh /tmp/

# OR use SCP:
scp install_modules_8_9.sh user@your-server:/tmp/
```

### Step 2: Run Installer
```bash
cd /tmp
chmod +x install_modules_8_9.sh
sudo ./install_modules_8_9.sh
```

### Step 3: Enjoy!
Script will automatically:
- ✅ Install Budget Keeper database (8 tables)
- ✅ Install Secure Settings database (9 tables)
- ✅ Deploy both PHP modules
- ✅ Update API router
- ✅ Restart Apache
- ✅ Run tests
- ✅ Show you results

**Total time: ~2 minutes!**

---

## ✅ VERIFICATION

### Test Budget Keeper:
```bash
curl -X POST http://localhost:8888/lifefirst/api.php \
  -H "Content-Type: application/json" \
  -d '{
    "action": "budget",
    "subaction": "get_settings",
    "user_id": 1
  }'
```

**Expected:**
```json
{
  "success": true,
  "settings": {
    "user_id": 1,
    "permission_level": 1,
    ...
  }
}
```

### Test Secure Settings:
```bash
curl -X POST http://localhost:8888/lifefirst/api.php \
  -d '{
    "action": "secure_settings",
    "subaction": "get_security_stats",
    "user_id": 1
  }'
```

**Expected:**
```json
{
  "success": true,
  "stats": {
    "user_id": 1,
    "total_unlock_attempts": 0,
    "overall_trust_score": 100.00,
    ...
  }
}
```

---

## 🔧 QUICK CONFIGURATION

### Set Jerry to Level 5 (Fort Knox):
```bash
curl -X POST http://localhost:8888/lifefirst/api.php \
  -d '{
    "action": "budget",
    "subaction": "update_settings",
    "user_id": 1,
    "permission_level": 5,
    "partner_user_id": 2,
    "accountability_threshold": 100.00,
    "require_partner_call": true,
    "cooling_off_minutes": 15,
    "enable_realtime_warnings": true
  }'
```

### Configure Secure Settings (Must be at home with Laurie!):
```bash
curl -X POST http://localhost:8888/lifefirst/api.php \
  -d '{
    "action": "secure_settings",
    "subaction": "setup_config",
    "user_id": 1,
    "partner_user_id": 2,
    "home_latitude": 33.1581,
    "home_longitude": -117.3506,
    "home_elevation": 28.5,
    "user_bluetooth_mac": "YOUR:MAC:HERE",
    "partner_bluetooth_mac": "LAURIE:MAC:HERE",
    "home_wifi_bssid": "ROUTER:MAC:HERE",
    "security_level": "fort_knox"
  }'
```

---

## 📊 CHECK STATUS

### Budget Health:
```bash
curl -X POST http://localhost:8888/lifefirst/api.php \
  -d '{"action":"budget","subaction":"get_budget_health","user_id":1}'
```

### Security Status:
```bash
curl -X POST http://localhost:8888/lifefirst/api.php \
  -d '{"action":"secure_settings","subaction":"check_unlock_status","user_id":1}'
```

### View All Categories:
```bash
curl -X POST http://localhost:8888/lifefirst/api.php \
  -d '{"action":"budget","subaction":"get_categories","user_id":1}'
```

---

## 🐛 TROUBLESHOOTING

### "MySQL connection failed"
```bash
# Check credentials in script
grep "DB_USER\|DB_PASS" install_modules_8_9.sh
```

### "Apache not running"
```bash
sudo systemctl start apache2
sudo systemctl status apache2
```

### Tables not created
```bash
# Check what tables exist:
mysql -u lifefirst_user -p lifefirst_db -e "SHOW TABLES;"

# Should see:
# - user_budget_settings
# - budget_categories
# - expenses
# - bill_reminders
# - accountability_rules
# - secure_settings_config
# - settings_unlock_attempts
# - security_violations
# + 9 more
```

### API not responding
```bash
# Check Apache logs:
sudo tail -f /var/log/apache2/error.log

# Restart Apache:
sudo systemctl restart apache2
```

---

## 🎯 WHAT'S NEXT?

After successful installation:

### 1. Configure Users
- Set your permission level (1-5)
- Link partners
- Set accountability rules

### 2. Set Up Security
- Record home GPS coordinates
- Get Bluetooth MAC addresses
- Note your WiFi BSSID

### 3. Cloudflare Setup
- Configure cloudflared tunnel
- Make API accessible from phones

### 4. Android Integration
- Update API endpoints
- Implement security checks
- Test purchase flow

---

## 💪 WHAT YOU NOW HAVE

**The Most Secure Budget App Ever Created:**

✅ **Smart Budget Management** (Module 8)
- 5 levels from basic to total accountability
- Real-time purchase warnings
- Bill reminders
- AI insights
- Partner notifications

✅ **Fort Knox Security** (Module 9)
- GPS + Elevation verification
- Partner presence required
- WiFi verification
- Behavioral analysis
- Impossible to hack remotely

**Combined Result:**
> "The ONLY budget app where you can't cheat even if you want to!"

---

## 🎉 SUCCESS CHECKLIST

- [ ] Script ran without errors
- [ ] 17 tables created
- [ ] Budget Keeper API responds
- [ ] Secure Settings API responds
- [ ] Categories initialized for user 1
- [ ] Security stats initialized
- [ ] Apache restarted successfully

**If all checked:** You're ready to move to Cloudflare setup! 🚀

---

## 📱 ANDROID INTEGRATION PREVIEW

Once Cloudflare is configured, your Android app will:

```kotlin
// Check purchase before checkout
val response = api.checkPurchase(
    userId = 1,
    amount = 150.00,
    merchant = "Best Buy"
)

if (response.requiresAction && response.actionType == "call_partner") {
    showCallPartnerDialog() // Level 5 enforcement!
}

// Try to change budget settings
val unlocked = securityApi.attemptUnlock(
    userId = 1,
    latitude = gps.latitude,
    longitude = gps.longitude,
    elevation = gps.altitude,
    partnerDetected = bluetooth.isPartnerNearby()
)

if (!unlocked.success) {
    showError("Not at home or partner not present")
}
```

---

## 🏆 YOU DID IT!

**Modules 8 & 9 are now installed!**

Next stop: **Cloudflare tunnel** so your phones can access the API! 🌐🔐

---

**Ready? Let's do Cloudflare next!** 🚀
